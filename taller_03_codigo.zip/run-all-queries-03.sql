-- run-all-queries-03.sql
-- Ejecuta los 29 archivos del taller 3 y guarda cada resultado en un .txt (un archivo por literal).
-- Los archivos con funciones tambien se ejecutan: crean la funcion y luego corren la consulta.

\encoding UTF8
\set ON_ERROR_STOP off
\pset pager off

\! mkdir "C:\Users\barro\Downloads\coffee_out_03"

\o 'C:/Users/barro/Downloads/coffee_out_03/ex_01_a.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_01_a.sql'
\o 'C:/Users/barro/Downloads/coffee_out_03/ex_01_b.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_01_b.sql'
\o 'C:/Users/barro/Downloads/coffee_out_03/ex_01_c.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_01_c.sql'

\o 'C:/Users/barro/Downloads/coffee_out_03/ex_02_a.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_02_a.sql'
\o 'C:/Users/barro/Downloads/coffee_out_03/ex_02_b.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_02_b.sql'
\o 'C:/Users/barro/Downloads/coffee_out_03/ex_02_c.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_02_c.sql'

\o 'C:/Users/barro/Downloads/coffee_out_03/ex_03_a.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_03_a.sql'
\o 'C:/Users/barro/Downloads/coffee_out_03/ex_03_b.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_03_b.sql'
\o 'C:/Users/barro/Downloads/coffee_out_03/ex_03_c.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_03_c.sql'

\o 'C:/Users/barro/Downloads/coffee_out_03/ex_04_a.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_04_a.sql'
\o 'C:/Users/barro/Downloads/coffee_out_03/ex_04_b.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_04_b.sql'
\o 'C:/Users/barro/Downloads/coffee_out_03/ex_04_c.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_04_c.sql'

\o 'C:/Users/barro/Downloads/coffee_out_03/ex_05_a.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_05_a.sql'
\o 'C:/Users/barro/Downloads/coffee_out_03/ex_05_b.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_05_b.sql'
\o 'C:/Users/barro/Downloads/coffee_out_03/ex_05_c.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_05_c.sql'

\o 'C:/Users/barro/Downloads/coffee_out_03/ex_06_a.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_06_a.sql'
\o 'C:/Users/barro/Downloads/coffee_out_03/ex_06_b.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_06_b.sql'
\o 'C:/Users/barro/Downloads/coffee_out_03/ex_06_c.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_06_c.sql'

\o 'C:/Users/barro/Downloads/coffee_out_03/ex_07_a.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_07_a.sql'
\o 'C:/Users/barro/Downloads/coffee_out_03/ex_07_b.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_07_b.sql'

\o 'C:/Users/barro/Downloads/coffee_out_03/ex_08_a.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_08_a.sql'
\o 'C:/Users/barro/Downloads/coffee_out_03/ex_08_b.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_08_b.sql'
\o 'C:/Users/barro/Downloads/coffee_out_03/ex_08_c.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_08_c.sql'

\o 'C:/Users/barro/Downloads/coffee_out_03/ex_09_a.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_09_a.sql'
\o 'C:/Users/barro/Downloads/coffee_out_03/ex_09_b.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_09_b.sql'
\o 'C:/Users/barro/Downloads/coffee_out_03/ex_09_c.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_09_c.sql'

\o 'C:/Users/barro/Downloads/coffee_out_03/ex_10_a.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_10_a.sql'
\o 'C:/Users/barro/Downloads/coffee_out_03/ex_10_b.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_10_b.sql'
\o 'C:/Users/barro/Downloads/coffee_out_03/ex_10_c.txt'
\i 'C:/Users/barro/OneDrive/Documents/GitHub/sql-101-mastering--109343332--2026-ii/content/coffe-coop/scripts/querys/03-sql-dates-strings-sets-functions/ex_10_c.sql'

\o
\echo 'Listo: 29 archivos ejecutados. Revise arriba si aparecio algun ERROR.'
