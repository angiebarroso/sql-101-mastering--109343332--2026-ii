-- Exercise 01 - c
-- NOW() and CURRENT_DATE in a single row, without a table

SELECT
    NOW() AS now_ts,
    CURRENT_DATE AS today;

/*
PEGUE AQUI EL RESULTADO
*/
