-- Exercise 04 - a
-- Top 10 longest closed certification periods of Pamplona farms

SELECT
    T2.farm_name AS farm,
    T3.certification_name AS certification,
    T1.start_date AS start_date,
    T1.end_date AS end_date,
    T1.end_date - T1.start_date AS duration_days,
    AGE(T1.end_date, T1.start_date) AS duration
FROM farm.farm_certifications AS T1
INNER JOIN farm.farms AS T2
    ON T1.farm_id = T2.farm_id
INNER JOIN farm.certifications AS T3
    ON T1.certification_id = T3.certification_id
WHERE T2.municipality_code = '54518'
  AND T1.end_date IS NOT NULL
ORDER BY T1.end_date - T1.start_date DESC, T2.farm_name ASC
LIMIT 10;

/*
PEGUE AQUI EL RESULTADO
*/
