-- Exercise 05 - a
-- Varieties: name in uppercase, species in lowercase and name length

SELECT
    UPPER(T1.variety_name) AS variety_upper,
    LOWER(T1.species) AS species,
    LENGTH(T1.variety_name) AS name_length
FROM farm.coffee_varieties AS T1
ORDER BY LENGTH(T1.variety_name) DESC, T1.variety_name ASC;

/*
PEGUE AQUI EL RESULTADO
*/
