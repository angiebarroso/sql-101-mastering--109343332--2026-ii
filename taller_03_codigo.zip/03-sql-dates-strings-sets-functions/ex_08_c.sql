-- Exercise 08 - c
-- Pamplona farms that delivered in 2025 but not in 2026 (EXCEPT)

SELECT
    T1.farm_name AS farm,
    T1.rural_district AS rural_district
FROM farm.farms AS T1
INNER JOIN buy.deliveries AS T2
    ON T1.farm_id = T2.farm_id
WHERE T1.municipality_code = '54518'
  AND EXTRACT(year FROM T2.delivered_at) = 2025
EXCEPT
SELECT
    T3.farm_name,
    T3.rural_district
FROM farm.farms AS T3
INNER JOIN buy.deliveries AS T4
    ON T3.farm_id = T4.farm_id
WHERE T3.municipality_code = '54518'
  AND EXTRACT(year FROM T4.delivered_at) = 2026
ORDER BY farm ASC, rural_district ASC;

/*
PEGUE AQUI EL RESULTADO
*/
