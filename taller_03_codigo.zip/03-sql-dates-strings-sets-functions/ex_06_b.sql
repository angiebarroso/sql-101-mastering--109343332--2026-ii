-- Exercise 06 - b
-- One sentence per collection point of Norte de Santander

SELECT
    CONCAT(T1.point_name, ' recibe café en ', T2.municipality_name) AS description
FROM buy.collection_points AS T1
INNER JOIN geo.municipalities AS T2
    ON T1.municipality_code = T2.municipality_code
WHERE T2.department_code = '54'
ORDER BY T1.point_name ASC;

/*
PEGUE AQUI EL RESULTADO
*/
