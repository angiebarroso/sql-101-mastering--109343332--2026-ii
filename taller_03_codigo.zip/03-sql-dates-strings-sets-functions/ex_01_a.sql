-- Exercise 01 - a
-- Farmers of Pamplona: seniority in days at today's date, longest first

SELECT
    T1.document_number AS document,
    T1.first_name AS first_name,
    T1.last_name AS last_name,
    T1.membership_date AS membership_date,
    CURRENT_DATE - T1.membership_date AS membership_days
FROM farm.farmers AS T1
WHERE T1.municipality_code = '54518'
ORDER BY T1.membership_date ASC;

/*
PEGUE AQUI EL RESULTADO
*/
