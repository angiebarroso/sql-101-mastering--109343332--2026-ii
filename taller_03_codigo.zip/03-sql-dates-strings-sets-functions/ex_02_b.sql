-- Exercise 02 - b
-- Pamplona: number of farmers and average age per gender

SELECT
    T1.gender AS gender,
    COUNT(*) AS farmers_count,
    ROUND(AVG(DATE_PART('year', AGE(DATE '2026-09-30', T1.birth_date)))::NUMERIC, 2) AS avg_age_years
FROM farm.farmers AS T1
WHERE T1.municipality_code = '54518'
GROUP BY T1.gender
ORDER BY T1.gender ASC;

/*
PEGUE AQUI EL RESULTADO
*/
