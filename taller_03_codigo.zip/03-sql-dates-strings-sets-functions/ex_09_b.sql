-- Exercise 09 - b
-- Function farm.fn_age_years(p_birth_date, p_reference_date): youngest members at affiliation

CREATE OR REPLACE FUNCTION farm.fn_age_years(p_birth_date DATE, p_reference_date DATE)
RETURNS INT
LANGUAGE plpgsql
AS $$
DECLARE
    v_age INT;
BEGIN
    SELECT DATE_PART('year', AGE(p_reference_date, p_birth_date))
    INTO v_age;

    RETURN v_age;
END;
$$;

SELECT
    T1.document_number AS document,
    T1.first_name AS first_name,
    T1.last_name AS last_name,
    farm.fn_age_years(T1.birth_date, DATE '2026-09-30') AS age_years,
    farm.fn_age_years(T1.birth_date, T1.membership_date) AS age_at_membership
FROM farm.farmers AS T1
WHERE T1.municipality_code = '54518'
ORDER BY farm.fn_age_years(T1.birth_date, T1.membership_date) ASC, T1.document_number ASC
LIMIT 10;

/*
PEGUE AQUI EL RESULTADO
*/
