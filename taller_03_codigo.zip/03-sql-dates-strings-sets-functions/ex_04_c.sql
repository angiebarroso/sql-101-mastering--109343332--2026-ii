-- Exercise 04 - c
-- 2026 deliveries per week (36 to 40) with first and last day of the year

SELECT
    EXTRACT(week FROM T1.delivered_at) AS week_number,
    COUNT(*) AS deliveries_count,
    MIN(EXTRACT(doy FROM T1.delivered_at)) AS first_day_of_year,
    MAX(EXTRACT(doy FROM T1.delivered_at)) AS last_day_of_year
FROM buy.deliveries AS T1
WHERE EXTRACT(year FROM T1.delivered_at) = 2026
  AND EXTRACT(week FROM T1.delivered_at) BETWEEN 36 AND 40
GROUP BY EXTRACT(week FROM T1.delivered_at)
ORDER BY EXTRACT(week FROM T1.delivered_at) ASC;

/*
PEGUE AQUI EL RESULTADO
*/
