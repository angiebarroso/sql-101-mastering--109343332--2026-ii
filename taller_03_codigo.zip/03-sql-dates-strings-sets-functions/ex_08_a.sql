-- Exercise 08 - a
-- Norte de Santander municipalities with farms AND a collection point (INTERSECT)

SELECT
    T2.municipality_code AS municipality_code,
    T2.municipality_name AS municipality
FROM farm.farms AS T1
INNER JOIN geo.municipalities AS T2
    ON T1.municipality_code = T2.municipality_code
WHERE T2.department_code = '54'
INTERSECT
SELECT
    T4.municipality_code,
    T4.municipality_name
FROM buy.collection_points AS T3
INNER JOIN geo.municipalities AS T4
    ON T3.municipality_code = T4.municipality_code
WHERE T4.department_code = '54'
ORDER BY municipality ASC;

/*
PEGUE AQUI EL RESULTADO
*/
