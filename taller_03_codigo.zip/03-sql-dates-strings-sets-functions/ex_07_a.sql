-- Exercise 07 - a
-- Phone directory: farmers of Pamplona plus Norte de Santander collection points with phone

SELECT
    'farmer' AS contact_type,
    CONCAT(T1.first_name, ' ', T1.last_name) AS contact_name,
    T1.phone_number AS phone
FROM farm.farmers AS T1
WHERE T1.municipality_code = '54518'
UNION ALL
SELECT
    'collection_point',
    T2.point_name,
    T2.phone_number
FROM buy.collection_points AS T2
WHERE T2.municipality_code LIKE '54%'
  AND T2.phone_number IS NOT NULL
ORDER BY contact_type ASC, contact_name ASC;

/*
PEGUE AQUI EL RESULTADO
*/
