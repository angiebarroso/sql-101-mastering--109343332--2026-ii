-- Exercise 10 - b
-- Settlements of 2026-09-30 deliveries, not cancelled, with balance > 0

CREATE OR REPLACE FUNCTION pay.fn_settlement_balance(p_settlement_id VARCHAR)
RETURNS NUMERIC
LANGUAGE plpgsql
AS $$
DECLARE
    v_net NUMERIC;
    v_paid NUMERIC;
BEGIN
    SELECT T1.net_amount
    INTO v_net
    FROM pay.settlements AS T1
    WHERE T1.settlement_id = p_settlement_id;

    SELECT SUM(T1.amount)
    INTO v_paid
    FROM pay.payments AS T1
    WHERE T1.settlement_id = p_settlement_id;

    RETURN v_net - COALESCE(v_paid, 0);
END;
$$;

SELECT
    T1.settlement_id AS settlement,
    T1.delivery_id AS delivery,
    T1.status AS settlement_status,
    T1.net_amount AS net_cop,
    pay.fn_settlement_balance(T1.settlement_id) AS balance_cop
FROM pay.settlements AS T1
INNER JOIN buy.deliveries AS T2
    ON T1.delivery_id = T2.delivery_id
WHERE T2.delivered_at::DATE = DATE '2026-09-30'
  AND T1.status <> 'cancelled'
  AND pay.fn_settlement_balance(T1.settlement_id) > 0
ORDER BY pay.fn_settlement_balance(T1.settlement_id) DESC;

/*
PEGUE AQUI EL RESULTADO
*/
