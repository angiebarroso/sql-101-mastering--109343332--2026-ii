-- Exercise 03 - a
-- September 2026 deliveries per day of the week (EXTRACT dow)

SELECT
    EXTRACT(dow FROM T1.delivered_at) AS day_of_week,
    COUNT(*) AS deliveries_count,
    SUM(T1.gross_weight_kg) AS total_gross_kg
FROM buy.deliveries AS T1
WHERE EXTRACT(year FROM T1.delivered_at) = 2026
  AND EXTRACT(month FROM T1.delivered_at) = 9
GROUP BY EXTRACT(dow FROM T1.delivered_at)
ORDER BY EXTRACT(dow FROM T1.delivered_at) ASC;

/*
PEGUE AQUI EL RESULTADO
*/
