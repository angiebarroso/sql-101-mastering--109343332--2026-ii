-- Exercise 04 - b
-- Current certifications (no end date) of Pamplona farms with 2+ years at 2026-09-30

SELECT
    T2.farm_name AS farm,
    T3.certification_name AS certification,
    T1.start_date AS start_date,
    DATE_PART('year', AGE(DATE '2026-09-30', T1.start_date)) AS years_active
FROM farm.farm_certifications AS T1
INNER JOIN farm.farms AS T2
    ON T1.farm_id = T2.farm_id
INNER JOIN farm.certifications AS T3
    ON T1.certification_id = T3.certification_id
WHERE T2.municipality_code = '54518'
  AND T1.end_date IS NULL
  AND DATE_PART('year', AGE(DATE '2026-09-30', T1.start_date)) >= 2
ORDER BY DATE_PART('year', AGE(DATE '2026-09-30', T1.start_date)) DESC, T2.farm_name ASC;

/*
PEGUE AQUI EL RESULTADO
*/
