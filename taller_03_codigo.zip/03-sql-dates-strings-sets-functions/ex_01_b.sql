-- Exercise 01 - b
-- Top 10 oldest members of Pamplona, seniority at 2026-09-30 (AGE and years only)

SELECT
    T1.document_number AS document,
    T1.first_name AS first_name,
    T1.last_name AS last_name,
    AGE(DATE '2026-09-30', T1.membership_date) AS membership_age,
    DATE_PART('year', AGE(DATE '2026-09-30', T1.membership_date)) AS membership_years
FROM farm.farmers AS T1
WHERE T1.municipality_code = '54518'
ORDER BY T1.membership_date ASC
LIMIT 10;

/*
PEGUE AQUI EL RESULTADO
*/
