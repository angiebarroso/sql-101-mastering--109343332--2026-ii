-- Exercise 06 - c
-- Deliveries of 2026-09-30 at Punto de Compra Bochalema 1 (id 163): code split with SUBSTRING

SELECT
    T1.delivery_id AS delivery,
    SUBSTRING(T1.delivery_id FROM 1 FOR 3) AS prefix,
    SUBSTRING(T1.delivery_id FROM 5 FOR 8) AS date_code,
    SUBSTRING(T1.delivery_id FROM 14 FOR 6) AS sequence_code,
    T1.delivered_at AS delivered_at
FROM buy.deliveries AS T1
WHERE T1.collection_point_id = 163
  AND T1.delivered_at::DATE = DATE '2026-09-30'
ORDER BY T1.delivered_at ASC;

/*
PEGUE AQUI EL RESULTADO
*/
