-- Exercise 07 - b
-- Norte de Santander municipality codes (farmers + farms): UNION vs UNION ALL

-- Version 1: UNION (removes duplicates)
SELECT
    T1.municipality_code AS municipality_code
FROM farm.farmers AS T1
WHERE T1.municipality_code LIKE '54%'
UNION
SELECT
    T2.municipality_code
FROM farm.farms AS T2
WHERE T2.municipality_code LIKE '54%'
ORDER BY municipality_code ASC;

-- Version 2: UNION ALL (keeps duplicates)
SELECT
    T1.municipality_code AS municipality_code
FROM farm.farmers AS T1
WHERE T1.municipality_code LIKE '54%'
UNION ALL
SELECT
    T2.municipality_code
FROM farm.farms AS T2
WHERE T2.municipality_code LIKE '54%'
ORDER BY municipality_code ASC;

/*
PEGUE AQUI EL RESULTADO
*/
