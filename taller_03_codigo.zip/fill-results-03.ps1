# fill-results-03.ps1
# Pega los resultados guardados en coffee_out_03\ como comentario /* ... */ al final de cada archivo .sql
# del taller 3. Conserva la consulta tal cual.
#  - Por defecto pega las primeras 10 filas de cada resultado y el total (como pide el taller).
#  - Para pegar TODAS las filas, ejecute el script con:  -MaxRows 0
#  - Los archivos con dos consultas (ex_05_c y ex_07_b) llevan los dos resultados.
#  - Tambien repara tildes dañadas (por ejemplo "AtlÃ¡ntico" -> "Atlántico").

param(
    [string]$SqlDir = 'C:\Users\barro\OneDrive\Documents\GitHub\sql-101-mastering--109343332--2026-ii\content\coffe-coop\scripts\querys\03-sql-dates-strings-sets-functions',
    [string]$OutDir = 'C:\Users\barro\Downloads\coffee_out_03',
    [int]$MaxRows = 10
)

$utf8   = New-Object System.Text.UTF8Encoding $false
$strict = New-Object System.Text.UTF8Encoding $false, $true
$cp1252 = [System.Text.Encoding]::GetEncoding(1252)

Get-ChildItem -Path $SqlDir -Filter 'ex_*.sql' | Sort-Object Name | ForEach-Object {
    $name    = $_.BaseName
    $outFile = Join-Path $OutDir ($name + '.txt')

    if (-not (Test-Path $outFile)) {
        Write-Host "[$name] No existe el archivo de resultado: $outFile" -ForegroundColor Yellow
        return
    }

    # Consulta = todo lo que hay antes del primer bloque /* */
    $sql = [System.IO.File]::ReadAllText($_.FullName, [System.Text.Encoding]::UTF8)
    $pos = $sql.IndexOf('/*')
    if ($pos -ge 0) { $query = $sql.Substring(0, $pos).TrimEnd() } else { $query = $sql.TrimEnd() }

    # Separar la salida de psql en bloques: cada bloque termina en "(N rows)"
    $lines   = [System.IO.File]::ReadAllLines($outFile, [System.Text.Encoding]::UTF8)
    $blocks  = New-Object System.Collections.ArrayList
    $current = New-Object System.Collections.ArrayList

    foreach ($line in $lines) {
        if ($line.Trim() -eq 'CREATE FUNCTION') { continue }

        if ($line -match '^\(\d+ rows?\)\s*$') {
            while ($current.Count -gt 0 -and $current[0].Trim() -eq '') { $current.RemoveAt(0) }
            while ($current.Count -gt 0 -and $current[$current.Count - 1].Trim() -eq '') { $current.RemoveAt($current.Count - 1) }
            [void]$blocks.Add(@{ Body = @($current); Footer = $line.Trim() })
            $current = New-Object System.Collections.ArrayList
        }
        else {
            [void]$current.Add($line)
        }
    }

    if ($blocks.Count -eq 0) {
        Write-Host "[$name] Sin resultado valido (la consulta pudo dar error). Revise en psql." -ForegroundColor Red
        return
    }

    # Armar el texto del comentario
    $parts = New-Object System.Collections.ArrayList
    $i = 0
    foreach ($b in $blocks) {
        $i++
        $body = @($b.Body)
        if ($MaxRows -gt 0 -and $body.Count -gt ($MaxRows + 2)) {
            $body = @($body | Select-Object -First ($MaxRows + 2)) + '...'
        }
        $text = ($body -join "`n") + "`n" + $b.Footer
        if ($blocks.Count -gt 1) { $text = "-- Result $i" + "`n" + $text }
        [void]$parts.Add($text)
    }
    $result = $parts -join "`n`n"

    # Reparar tildes dañadas si las hay
    if ($result -match '[\u00C2\u00C3]') {
        try { $result = $strict.GetString($cp1252.GetBytes($result)) } catch { }
    }

    $new = $query + "`n`n/*`n" + $result + "`n*/`n"
    [System.IO.File]::WriteAllText($_.FullName, $new, $utf8)

    $totales = ($blocks | ForEach-Object { $_.Footer }) -join ' '
    Write-Host "[$name] OK - $totales" -ForegroundColor Green
}
